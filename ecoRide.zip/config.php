<?php

define('registration_credit', 20);
define('booking_credit', 15);

//send cancelation message to customers from this email
define('sender_email', '');

//send contact messages to this email
define('to_email', '');
